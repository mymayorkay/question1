<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
   <script src="jquery/jquery.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="container-fluid">
  <div class="row">
  <div class="col-md-3">

   
    </div>
    <div class="col-md-6">
    <!-- begining of form -->
<font color="#FF0004" size="+5"> Congratulation Your Application has been submitted!!! </font>
<br /><br />
<font color="blue" size="+2"><p align="center"><a href="myregistration.php"> Click Here to Register another Applicant</a></p> </font>
  <!-- closing of form -->
    </div>
    <div class="col-md-3">
    
    </div>
  </div>
  </div>
</body>
</html>
