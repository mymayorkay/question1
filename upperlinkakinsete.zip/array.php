<?php

$A =  [1, 3, 6, 4, 1, 2];

$new_array = array();

$p_max = max($A);
// loop
for($i=1;$i<$p_max;$i++){
    
    if(!in_array($i,$A)){
     
      $new_array[]=$i;  
    }
}
echo "The smallest value is &nbsp;". $myarray = empty($new_array) ? $p_max+1 : min($new_array);


?>