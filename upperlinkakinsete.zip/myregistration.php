<?php

// connection
require_once "db/db_con.php";

if (isset($_POST['buton']))
{
	$a = mysqli_real_escape_string($con, trim($_POST["fname"]));
	$b = mysqli_real_escape_string($con, trim($_POST["sname"]));
	$c = mysqli_real_escape_string($con, trim($_POST["email"]));
	$d = mysqli_real_escape_string($con, trim($_POST["phone"]));
	$e = mysqli_real_escape_string($con, trim($_POST["cover"]));
	
	
	
$file_cv = $_FILES['mycv'];

if(empty($a) || empty($c))
		{
			$msgs =  'One or more required field missing!<br>';
		}
		
		if($c=="")
			{ 		
				$msgs="* Enter your email address... <br> ";
			}
			
		else
		{
		}
					
		$sqlt = "SELECT * From applicant WHERE email='$c'";
		$responder = mysqli_query($con,$sqlt);
	   if (mysqli_num_rows($responder)==1)
			{
				$msgs="Email address already used by a user please use another... <br>";
			}
			
		     
  
  
								
                                   if ($result = mysqli_query($con, "SELECT * FROM applicant ORDER BY id")) {
                                     $row_cnt = mysqli_num_rows($result);
									 
									 if ($row_cnt == 4)
									 {
										 
										 $msgs="Application Closed. <br>";
										 
									 }
									     mysqli_free_result($result);
}
                                       



	


// cv uploader

if(!empty($file_cv)) {
		$max_file = 2048;
		$fieldName = 'mycv';
		$uploadPath = "cv/";
		$desFileName = $a.rand(1000,3000);
		$userfile_name = $_FILES[$fieldName]['name'];
		$userfile_tmp = $_FILES[$fieldName]['tmp_name'];
		$userfile_size = ($_FILES[$fieldName]['size'])/1024;
		$filename = basename($_FILES[$fieldName]['name']);
		$file_ext = substr($filename, strrpos($filename, '.') + 1);



					if (($file_ext!="doc" && $file_ext!="docx"  && $file_ext!="pdf"))
					{
						$msgs= 'You can Only upload this file format <br> .DOC, .DOCX,  .PDF';
					}
				
					if($userfile_size > $max_file)
					{
						$msgs= "ONLY files under 2048 are accepted for upload <br>";
					}


}




	if(!isset($msgs))
	{
		
	$imagedir = $uploadPath;
		$image = $desFileName.'.'.$file_ext; //substr(md5(uniqid()),1,8).'.'.$file_ext;
		$imagepath = $imagedir.$image;
		move_uploaded_file($userfile_tmp, $imagepath);
		

$picture=$_FILES["pic"]["name"];
$picturetype=$_FILES["pic"]["type"];
$picturetemp=$_FILES["pic"]["tmp_name"];

move_uploaded_file($picturetemp,"mypix/".$picture);
$ImageDir=move_uploaded_file($picturetemp,"mypix/".$picture);

	
		
	
		
		
		$insert = "INSERT INTO applicant (firstname,surname,phonenumber,email,coverletter,passport,resume) VALUES ('$a','$b','$d','$c','$e','$picture','$image')";
		
		
	$query_insert = mysqli_query($con,$insert) or die(mysqli_error());
	if($query_insert)
	{
		$msg = "Successful";
	
		
		header('Location:congratreg.php');
	}
	}
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Upper Link Applicant </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2><p align="center">Registration form</p></h2><br>
  <?php 
		  if(isset($msg)) 
		  {
			   echo "<span class='alert-success'> $msg </span>";
		   }
		   if(isset($msgs)) { echo '<font color="red" size="+3">'."<span class='alert-error'> $msgs </span>".'</font>';}
		   ?>
  <br>
 
  <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
  <div class="form-group">
      <label class="control-label col-sm-2" for="pass">First Name:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="fname" placeholder="Enter Your First Name" name="fname">
      </div>
    </div>
    
      <div class="form-group">
      <label class="control-label col-sm-2" for="pass">SurName:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="sname" placeholder="Enter Your Surname" name="sname">
      </div>
    </div>
    
      <div class="form-group">
      <label class="control-label col-sm-2" for="pass">Phone Number:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="phone" placeholder="Enter Your Phone Number" name="phone">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10">
        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
      </div>
    </div>
 
    <div class="form-group">
      <label class="control-label col-sm-2" for="pass">Cover Letter:</label>
      <div class="col-sm-10">          
         <textarea class="form-control" name="cover" placeholder="Type your Cover Letter"></textarea>
      </div>
      
    <div class="form-group">
      <label class="control-label col-sm-2" for="pass">Upload your Passport</label>
      <div class="col-sm-10">          
         <input name="pic" type="file" id="pic" size="45" />
      </div>
    </div>
    
        <div class="form-group">
      <label class="control-label col-sm-2" for="pass">Upload your Resume</label>
      <div class="col-sm-10">          
         <input name="mycv" type="file" id="mycv" size="45" />
      </div>
    </div>
   
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default" name="buton">Submit</button>
      </div>
    </div>
  </form>
</div>

</body>
</html>
