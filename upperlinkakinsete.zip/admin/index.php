<?php
ob_start();
session_start();
require_once "../db/db_con.php";
if(isset($_POST['go'])){
$username=$_POST['username'];
							$password=$_POST['password'];
					$passwordecr=(md5($password));		
								
								$result = mysqli_query($con,"SELECT * FROM admin WHERE username ='$username' AND password = '$passwordecr'") or die(mysqli_error());
							
								$row = mysqli_fetch_array($result);
								$numberOfRows = mysqli_num_rows($result);				
																	
																
																if ($numberOfRows == 0) 
																	{
																		echo " <br><center><font color= 'red' size='3'>Invalid Username or password
																		</center></font>";
																	} 
																else if ($numberOfRows > 0)	{ 
									$_SESSION['id'] = $row['id'];
                                                                    header("location:dashboard.php");
																
															}	
							
							}	?>
							<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset="UTF-8" /> 
    <title>HOSPITAL JOBS MANAGEMENT SYSTEM</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<form method = "post" >
  <h1>Administrator Log in</h1>
  <div class="inset">
  <p>
    <label for="email">USERNAME</label>
    <input style = "color:white;"type="text" name="username" id="email">
  </p>
  <p>
    <label for="password">PASSWORD</label>
    <input style = "color:white;" type="password" name="password" id="password">
  </p>

  </div>
   <center><p class="p-container" >
  
    <input type="submit" name="go" id="go" value="Log in">
	
  </p>
  </center>
</form>
	



</body>
</html>
