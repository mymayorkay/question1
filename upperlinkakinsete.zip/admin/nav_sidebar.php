 <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a href="#"><i class="fa fa-dashboard"></i> Menu's</a>
                    </li>
                    <li>
                        <a href="dashboard.php"><i class="fa fa-gear"></i>VIEW ALL APPLICANTS</a>
                    </li>
				
					   <li>
                        <a href="logout.php"><i class="fa fa-user"></i> Log out </a>
                    </li>


               
                 
                </ul>

            </div>

        </nav>