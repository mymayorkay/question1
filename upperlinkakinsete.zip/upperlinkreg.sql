-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2018 at 12:32 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `upperlinkreg`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicant`
--

CREATE TABLE `applicant` (
  `id` int(15) NOT NULL,
  `firstname` varchar(80) DEFAULT NULL,
  `surname` varchar(80) DEFAULT NULL,
  `phonenumber` varchar(80) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `coverletter` text,
  `passport` varchar(200) DEFAULT NULL,
  `resume` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicant`
--

INSERT INTO `applicant` (`id`, `firstname`, `surname`, `phonenumber`, `email`, `coverletter`, `passport`, `resume`) VALUES
(1, 'Akinsete', 'Kayode', '08034089466', 'mayork2012@gmail.com', 'welcome sir', 'IMG_20170122_102423.jpg', 'Akinsete1360.docx'),
(2, 'Shittu', 'Balogun', '09056453276', 'shitu@y.com', 'the lord is good', 'coronna.jpg', 'Shittu2156.pdf'),
(3, 'Ibraim', 'Dan', '08034089466', 'adgexbaba@yaoo.com', 'am cool', 'IMG_4655.JPG', 'Ibraim2971.docx'),
(4, 'Toyin', 'Salako', '08034477821', 'toyinsalako@y.com', 'am on it', 'kay 1.jpg', 'Toyin2835.docx');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicant`
--
ALTER TABLE `applicant`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applicant`
--
ALTER TABLE `applicant`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
